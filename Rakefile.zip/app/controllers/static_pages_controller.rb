class StaticPagesController < ApplicationController
  def home
  end

  def signup
  end
end
